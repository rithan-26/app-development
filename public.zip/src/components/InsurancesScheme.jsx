import React from 'react';
import '../styles/InsuranceSchemes.css';
import img10 from '../images/img10.jpg'
import img11 from '../images/img11.jpg'
import img12 from '../images/img12.jpg'
import img13 from '../images/img13.jpg'
import img14 from '../images/img14.png'
import img15 from '../images/img15.png'
const schemes = [
  {
    id: 1,
    name: 'Family Protection Plan',
    description: 'Comprehensive coverage for your entire family with affordable premiums.',
    benefits: [
      'Covers accidental death',
      'Covers critical illnesses',
      'Flexible payment options',
      '24/7 customer support'
    ],
    imageUrl: img10,
    moreInfoUrl:"/family-protection",
  },
  {
    id: 2,
    name: 'Retirement Savings Plan',
    description: 'Secure your retirement with our guaranteed savings and life cover.',
    benefits: [
      'Guaranteed returns',
      'Tax benefits',
      'Pension payout options',
      'Customizable plans'
    ],
    imageUrl: img11,
    moreInfoUrl: '/retirement-savings'
  },
  {
    id: 3,
    name: 'Child Education Plan',
    description: 'Plan for your child’s future education with life cover and savings.',
    benefits: [
      'Education fund',
      'Life cover',
      'Flexible withdrawal options',
      'Future financial security'
    ],
    imageUrl: img12,
    moreInfoUrl: '/child-education'
  },
  {
    id: 4,
    name: 'Term Life Insurance',
    description: 'Affordable term life insurance that provides high coverage with minimal cost.',
    benefits: [
      'High coverage at low cost',
      'Simple application process',
      'No medical exam for qualified applicants',
      'Optional riders for extra protection'
    ],
    imageUrl: img13,
    moreInfoUrl: '/term-life'
  },
  {
    id: 5,
    name: 'Whole Life Insurance',
    description: 'Lifetime protection with cash value accumulation and fixed premiums.',
    benefits: [
      'Lifetime coverage',
      'Cash value accumulation',
      'Fixed premiums',
      'Tax-deferred growth'
    ],
    imageUrl: img14,
    moreInfoUrl: '/whole-life'
  },
  {
    id: 6,
    name: 'Universal Life Insurance',
    description: 'Flexible premium payments and death benefits with a savings component.',
    benefits: [
      'Flexible premium payments',
      'Savings component',
      'Adjustable death benefit',
      'Tax-deferred growth'
    ],
    imageUrl: img15,
    moreInfoUrl: '/universal-life'
  }
];

const InsuranceSchemes = () => {
  return (
    <div className="insurance-schemes">
      <h2>Explore Our Insurance Schemes</h2>
      <div className="scheme-cards">
        {schemes.map(scheme => (
          <div className="scheme-card" key={scheme.id}>
            <img src={scheme.imageUrl} alt={scheme.name} className="scheme-image" />
            <div className="scheme-content">
              <h3>{scheme.name}</h3>
              <p>{scheme.description}</p>
              <ul className="scheme-benefits">
                {scheme.benefits.map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))}
              </ul>
              <a href={scheme.moreInfoUrl} className="more-info-link">Learn More</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InsuranceSchemes;
