import React from 'react';
import '../styles/AboutPage.css';

const AboutPage = () => {
  return (
    <div className="about-page">
      <div className="about-header">
        <h1>About Us</h1>
        <p>Learn more about our company, mission, and values.</p>
      </div>
      <div className="about-content">
        <section className="company-overview">
          <h2>Company Overview</h2>
          <p>
            At Life Insurance Co., we are dedicated to providing exceptional insurance products and services to our clients. With decades of experience in the industry, our mission is to ensure that every family has the financial protection they need in times of uncertainty.
          </p>
          <p>
            Our commitment to our clients extends beyond just offering insurance policies. We strive to build long-lasting relationships based on trust and reliability. Our team of experts is always ready to assist you in finding the right coverage for your unique needs.
          </p>
        </section>
        <section className="our-mission">
          <h2>Our Mission</h2>
          <p>
            Our mission is to empower individuals and families by providing comprehensive insurance solutions that offer peace of mind and financial security. We believe in making insurance accessible, affordable, and understandable for everyone.
          </p>
        </section>
        <section className="core-values">
          <h2>Core Values</h2>
          <ul>
            <li>
              <strong>Integrity:</strong> We uphold the highest standards of integrity in all our actions.
            </li>
            <li>
              <strong>Customer Focus:</strong> Our customers are at the heart of everything we do.
            </li>
            <li>
              <strong>Innovation:</strong> We continuously seek new ways to improve our products and services.
            </li>
            <li>
              <strong>Community:</strong> We are committed to making a positive impact in the communities we serve.
            </li>
            <li>
              <strong>Excellence:</strong> We strive for excellence in everything we do, delivering quality and value to our clients.
            </li>
          </ul>
        </section>
        <section className="our-team">
          <h2>Our Team</h2>
          <p>
            Our team consists of experienced professionals who are passionate about helping you achieve financial security. We believe in continuous learning and development, ensuring that our team is equipped with the latest knowledge and skills to serve you better.
          </p>
        </section>
        <section className="contact-information">
          <h2>Contact Information</h2>
          <p>If you have any questions or would like to learn more about our services, please don't hesitate to contact us:</p>
          <p><strong>Email:</strong> info@lifeinsuranceco.com</p>
          <p><strong>Phone:</strong> +1 (234) 567-890</p>
          <p><strong>Address:</strong> 1234 Insurance Avenue, Suite 500, Capital City, Country</p>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;
