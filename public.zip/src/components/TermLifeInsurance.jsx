import React from 'react';
import '../styles/TermLifeInsurance.css';
import img13 from '../images/img13.jpg'
import { Link } from 'react-router-dom';

const TermLifeInsurance = () => {
  const planDetails = {
    name: 'Term Life Insurance Plan',
    imageUrl: img13, // Replace with actual image path
    longDescription: 'The Term Life Insurance Plan offers a simple and affordable way to protect your family’s financial future. In the unfortunate event of the policyholder’s demise during the policy term, the plan provides a lump sum payout to the beneficiaries. This plan is ideal for those looking for high coverage at low premiums.',
    benefits: [
      'High coverage at affordable premiums',
      'Simple and straightforward plan',
      'Flexible policy terms and premium payment options',
      'Option to enhance coverage with additional riders',
      'Tax benefits under Section 80C and 10(10D)',
      'Option to convert to permanent life insurance'
    ],
    features: [
      'Wide range of sum assured options',
      'Policy term from 5 to 40 years',
      'Premium payment modes - yearly, half-yearly, quarterly, monthly',
      'Accidental death benefit rider',
      'Critical illness rider',
      'Waiver of premium rider'
    ],
    brochureUrl: 'path/to/term-life-insurance-brochure.pdf', // Replace with actual brochure path
    videoUrl: 'https://www.youtube.com/embed/examplevideo' // Replace with actual video URL
  };

  return (
    <div className="term-life-insurance">
      <div className="plan-header">
        <img src={planDetails.imageUrl} alt={planDetails.name} className="plan-banner" />
        <h1>{planDetails.name}</h1>
      </div>
      <div className="plan-content">
        <div className="plan-description">
          <h2>Description</h2>
          <p>{planDetails.longDescription}</p>
        </div>
        <div className="plan-details">
          <div className="plan-benefits">
            <h2>Key Benefits</h2>
            <ul>
              {planDetails.benefits.map((benefit, index) => (
                <li key={index}>{benefit}</li>
              ))}
            </ul>
          </div>
          <div className="plan-features">
            <h2>Features</h2>
            <ul>
              {planDetails.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="plan-resources">
          <h2>Additional Resources</h2>
          <a href={planDetails.brochureUrl} className="resource-link" download>
            Download Brochure
          </a>
          {planDetails.videoUrl && (
            <div className="plan-video">
              <h3>Watch our video:</h3>
              <iframe
                src={planDetails.videoUrl}
                title="Term Life Insurance Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
          <br />
          <br />
          <br />
          <br/>
          <br/>
          <br/>

         <button style={{width:"250px"}}><Link to='/userdetails-payment'>Apply Now</Link></button>

        </div>
      </div>
    </div>
  );
};

export default TermLifeInsurance;
