import React from 'react';
import '../styles/UniversalLifeInsurance.css';
import img15 from '../images/img15.png'
import { Link } from 'react-router-dom';

const UniversalLifeInsurance = () => {
  const planDetails = {
    name: 'Universal Life Insurance Plan',
    imageUrl: img15, // Replace with actual image path
    longDescription: 'The Universal Life Insurance Plan offers lifelong coverage with flexible premium payments and the potential to build cash value. This plan is ideal for those who want the protection of life insurance with the ability to adjust coverage and premiums to suit changing financial needs. The plan’s cash value component grows over time, offering a valuable resource that can be accessed through loans or withdrawals.',
    benefits: [
      'Flexible premium payments and coverage amounts',
      'Potential to build cash value over time',
      'Tax-deferred growth on cash value',
      'Ability to access cash value through loans or withdrawals',
      'Adjustable death benefit to meet changing needs',
      'Optional riders for additional protection'
    ],
    features: [
      'Lifelong coverage with adjustable premiums',
      'Cash value accumulation with tax advantages',
      'Choice of investment options within the policy',
      'No-lapse guarantee option to ensure coverage',
      'Flexibility to increase or decrease the death benefit',
      'Option to add riders for critical illness, disability, and more'
    ],
    brochureUrl: 'path/to/universal-life-insurance-brochure.pdf', // Replace with actual brochure path
    videoUrl: 'https://www.youtube.com/embed/examplevideo' // Replace with actual video URL
  };

  return (
    <div className="universal-life-insurance">
      <div className="plan-header">
        <img src={planDetails.imageUrl} alt={planDetails.name} className="plan-banner" />
        <h1>{planDetails.name}</h1>
      </div>
      <div className="plan-content">
        <div className="plan-description">
          <h2>Description</h2>
          <p>{planDetails.longDescription}</p>
        </div>
        <div className="plan-details">
          <div className="plan-benefits">
            <h2>Key Benefits</h2>
            <ul>
              {planDetails.benefits.map((benefit, index) => (
                <li key={index}>{benefit}</li>
              ))}
            </ul>
          </div>
          <div className="plan-features">
            <h2>Features</h2>
            <ul>
              {planDetails.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="plan-resources">
          <h2>Additional Resources</h2>
          <a href={planDetails.brochureUrl} className="resource-link" download>
            Download Brochure
          </a>
          {planDetails.videoUrl && (
            <div className="plan-video">
              <h3>Watch our video:</h3>
              <iframe
                src={planDetails.videoUrl}
                title="Universal Life Insurance Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
          <br />
          <br />
          <br />
          <br/>
          <br/>
          <br/>

         <button style={{width:"250px"}}><Link to='/userdetails-payment'>Apply Now</Link></button>
        </div>
      </div>
    </div>
  );
};

export default UniversalLifeInsurance;
