import React from 'react';
import '../styles/FamilyProtectionPlan.css';
import img10 from '../images/img10.jpg'
import { Link } from 'react-router-dom';
const FamilyProtectionPlan = () => {
  const scheme = {
    name: 'Family Protection Plan',
    imageUrl: img10,
    longDescription: 'Our Family Protection Plan offers comprehensive coverage to ensure the financial security of your family in case of unforeseen circumstances. This plan covers a wide range of situations, including accidental death, critical illnesses, and more, providing peace of mind for you and your loved ones.',
    benefits: [
      'Comprehensive coverage for all family members',
      'Accidental death benefit',
      'Critical illness coverage',
      'Flexible premium payment options',
      '24/7 customer support',
      'Tax benefits under Section 80C'
    ],
    features: [
      'Option to add additional riders for enhanced coverage',
      'Flexible sum assured',
      'Premium waiver in case of total disability',
      'Loan facility against policy',
      'Guaranteed maturity benefits'
    ],
    brochureUrl: 'path/to/family-protection-brochure.pdf',
    videoUrl: 'https://www.youtube.com/embed/examplevideo'
  };

  return (
    <div className="family-protection-plan">
      <div className="scheme-header">
        <img src={scheme.imageUrl} alt={scheme.name} className="scheme-banner" />
        <h1>{scheme.name}</h1>
      </div>
      <div className="scheme-content">
        <div className="scheme-description">
          <h2>Description</h2>
          <p>{scheme.longDescription}</p>
        </div>
        <div className="scheme-details">
          <div className="scheme-benefits">
            <h2>Key Benefits</h2>
            <ul>
              {scheme.benefits.map((benefit, index) => (
                <li key={index}>{benefit}</li>
              ))}
            </ul>
          </div>
          <div className="scheme-features">
            <h2>Features</h2>
            <ul>
              {scheme.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="scheme-resources">
          <h2>Additional Resources</h2>
          <a href={scheme.brochureUrl} className="resource-link" download>
            Download Brochure
          </a>
          {scheme.videoUrl && (
            <div className="scheme-video">
              <h3>Watch our video:</h3>
              <iframe
                src={scheme.videoUrl}
                title="Family Protection Plan Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
          <br />
          <br />
          <br />
          <br/>
          <br/>
          <br/>

         <button style={{width:"250px"}}><Link to='/userdetails-payment'>Apply Now</Link></button>
        </div>
      </div>
    </div>
  );
};

export default FamilyProtectionPlan;
