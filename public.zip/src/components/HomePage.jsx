import React from 'react';
import '../styles/HomePage.css';
import img7 from '../images/img7.png'
import img8 from '../images/img8.jpg'
import img9 from '../images/img9.jpg'
const HomePage = () => {
  return (
    <div className="home-page">
      <header className="hero-section">
        <div className="hero-content">
          <h1>Protect Your Loved Ones with Our Comprehensive Life Insurance Plans</h1>
          <p>Explore our range of life insurance policies designed to provide peace of mind and security for you and your family.</p>
          <a href="/signup" className="cta-button">Get Started</a>
        </div>
      </header>
      
      <section className="features-section">
        <h2>Our Key Features</h2>
        <div className="features">
          <div className="feature">
            <img src={img7} alt="Flexible Policies" />
            <h3>Flexible Policies</h3>
            <p>Customize your coverage to fit your unique needs and budget, ensuring you have the protection you need.</p>
          </div>
          <div className="feature">
            <img src={img8} alt="Affordable Rates" />
            <h3>Affordable Rates</h3>
            <p>We offer competitive pricing, so you can protect your family without breaking the bank.</p>
          </div>
          <div className="feature">
            <img src={img9} alt="Expert Advisors" />
            <h3>Expert Advisors</h3>
            <p>Our experienced advisors are here to guide you through the process and help you find the perfect plan.</p>
          </div>
        </div>
      </section>

      <section className="testimonials-section">
        <h2>Testimonials</h2>
        <div className="testimonials">
          <div className="testimonial">
            <p>"This insurance company made it easy for me to find the perfect plan. Their customer service is outstanding!"</p>
            <h4>- Jane S.</h4>
          </div>
          <div className="testimonial">
            <p>"Affordable and reliable. I feel confident that my family is protected."</p>
            <h4>- Mark A.</h4>
          </div>
          <div className="testimonial">
            <p>"The advisors were incredibly helpful in choosing the right coverage for my needs."</p>
            <h4>- Emily R.</h4>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <h2>Ready to Get Started?</h2>
        <p>Join thousands of satisfied customers who have found peace of mind with our life insurance plans.</p>
        <a href="/signup" className="cta-button">Sign Up Today</a>
      </section>

      <section className="info-section">
        <h2>Learn More About Our Insurance Plans</h2>
        <div className="info-cards">
          <div className="info-card">
            <h3>Types of Insurance</h3>
            <p>Discover the different types of insurance we offer and find the one that suits you best.</p>
            <a href="/learn-more" className="info-link">Learn More</a>
          </div>
          <div className="info-card">
            <h3>How It Works</h3>
            <p>Understand the process and benefits of our insurance plans.</p>
            <a href="/learn-more" className="info-link">Learn More</a>
          </div>
          <div className="info-card">
            <h3>FAQs</h3>
            <p>Got questions? We have answers. Check out our FAQ section for more information.</p>
            <a href="/faq" className="info-link">Read FAQs</a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
