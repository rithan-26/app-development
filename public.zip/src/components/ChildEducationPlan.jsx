import React from 'react';
import '../styles/ChildEducationPlan.css';
import img12 from '../images/img12.jpg'
import { Link } from 'react-router-dom';

const ChildEducationPlan = () => {
  const planDetails = {
    name: 'Child Education Plan',
    imageUrl: img12, // Replace with actual image path
    longDescription: 'The Child Education Plan is designed to provide a secure financial future for your child’s education. This plan helps you accumulate savings over time to cover the rising costs of education. It also offers life cover to ensure your child’s dreams are fulfilled even in your absence.',
    benefits: [
      'Guaranteed payouts at key educational milestones',
      'Tax benefits under Section 80C and 10(10D)',
      'Comprehensive life cover for the policyholder',
      'Flexible premium payment options',
      'Option to add riders for enhanced protection',
      'No-risk capital with guaranteed returns'
    ],
    features: [
      'Multiple policy term options',
      'Choice of funds for investment',
      'Partial withdrawal facility for urgent needs',
      'Top-up option for additional savings',
      'Loyalty additions and bonuses',
      'Loan against policy option'
    ],
    brochureUrl: 'path/to/child-education-brochure.pdf', // Replace with actual brochure path
    videoUrl: 'https://www.youtube.com/embed/examplevideo' // Replace with actual video URL
  };

  return (
    <div className="child-education-plan">
      <div className="plan-header">
        <img src={planDetails.imageUrl} alt={planDetails.name} className="plan-banner" />
        <h1>{planDetails.name}</h1>
      </div>
      <div className="plan-content">
        <div className="plan-description">
          <h2>Description</h2>
          <p>{planDetails.longDescription}</p>
        </div>
        <div className="plan-details">
          <div className="plan-benefits">
            <h2>Key Benefits</h2>
            <ul>
              {planDetails.benefits.map((benefit, index) => (
                <li key={index}>{benefit}</li>
              ))}
            </ul>
          </div>
          <div className="plan-features">
            <h2>Features</h2>
            <ul>
              {planDetails.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="plan-resources">
          <h2>Additional Resources</h2>
          <a href={planDetails.brochureUrl} className="resource-link" download>
            Download Brochure
          </a>
          {planDetails.videoUrl && (
            <div className="plan-video">
              <h3>Watch our video:</h3>
              <iframe
                src={planDetails.videoUrl}
                title="Child Education Plan Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
          <br />
          <br />
          <br />
          <br/>
          <br/>
          <br/>

         <button style={{width:"250px"}}><Link to='/userdetails-payment'>Apply Now</Link></button>
        </div>
      </div>
    </div>
  );
};

export default ChildEducationPlan;
