import React from 'react';
import '../styles/RetirementSavingsPlan.css';
import img11 from '../images/img11.jpg'
import { Link } from 'react-router-dom';

const RetirementSavingsPlan = () => {
  const planDetails = {
    name: 'Retirement Savings Plan',
    imageUrl: img11, // Replace with actual image path
    longDescription: 'The Retirement Savings Plan is designed to provide financial security in your golden years. It helps you build a substantial corpus over time, ensuring a steady income post-retirement. This plan offers a variety of flexible investment options, tax benefits, and life cover, making it an essential part of your retirement planning.',
    benefits: [
      'Steady income post-retirement',
      'Tax benefits under Section 80C',
      'Flexible investment options',
      'Life cover and protection for your family',
      'Option to choose annuity plans',
      'No-risk capital with guaranteed returns'
    ],
    features: [
      'Customizable premium payment terms',
      'Multiple fund options',
      'Partial withdrawal facility',
      'Top-up options for additional savings',
      'Guaranteed maturity benefits',
      'Loan against policy option'
    ],
    brochureUrl: 'path/to/retirement-savings-brochure.pdf', // Replace with actual brochure path
    videoUrl: 'https://www.youtube.com/embed/examplevideo' // Replace with actual video URL
  };

  return (
    <div className="retirement-savings-plan">
      <div className="plan-header">
        <img src={planDetails.imageUrl} alt={planDetails.name} className="plan-banner" />
        <h1>{planDetails.name}</h1>
      </div>
      <div className="plan-content">
        <div className="plan-description">
          <h2>Description</h2>
          <p>{planDetails.longDescription}</p>
        </div>
        <div className="plan-details">
          <div className="plan-benefits">
            <h2>Key Benefits</h2>
            <ul>
              {planDetails.benefits.map((benefit, index) => (
                <li key={index}>{benefit}</li>
              ))}
            </ul>
          </div>
          <div className="plan-features">
            <h2>Features</h2>
            <ul>
              {planDetails.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>
        </div>
        <div className="plan-resources">
          <h2>Additional Resources</h2>
          <a href={planDetails.brochureUrl} className="resource-link" download>
            Download Brochure
          </a>
          {planDetails.videoUrl && (
            <div className="plan-video">
              <h3>Watch our video:</h3>
              <iframe
                src={planDetails.videoUrl}
                title="Retirement Savings Plan Video"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          )}
         <br />
          <br />
          <br />
          <br/>
          <br/>
          <br/>

         <button style={{width:"250px"}}><Link to='/userdetails-payment'>Apply Now</Link></button>

        </div>
      </div>
    </div>
  );
};

export default RetirementSavingsPlan;
