import React from 'react';
import { BrowserRouter as Router, Route, Switch, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './components/HomePage';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import ContactPage from './components/ContactPage';
import AboutPage from './components/AboutPage';
import './App.css';
import InsuranceSchemes from './components/InsurancesScheme';
import FamilyProtectionPlan from './components/FamilyProtectionPlan';
import ChildEducationPlan from './components/ChildEducationPlan';
import RetirementSavingsPlan from './components/RetirementSavingsPlan';
import TermLifeInsurance from './components/TermLifeInsurance';
import WholeLifeInsurance from './components/WholeLifeInsurance';
import UniversalLifeInsurance from './components/UniversalLifeInsurance';
import UserDetailsAndPayment from './components/UserDetailsAndPayment';

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          <Route path="/" exact element={<HomePage/>} />
          <Route path="/login" element={<LoginPage/>} />
          <Route path="/signup" element={<SignupPage/>} />
          <Route path="/contact" element={<ContactPage/>} />
          <Route path="/about" element={<AboutPage/>} />
          <Route path='/insurance' element={<InsuranceSchemes/>}/>
          <Route path='/family-protection' element={<FamilyProtectionPlan/>}/>
          <Route path='/retirement-savings' element={<RetirementSavingsPlan/>}/>
          <Route path='/child-education' element={<ChildEducationPlan/>}/>
          <Route path='/term-life' element={<TermLifeInsurance/>}/>
          <Route path='/whole-life' element={<WholeLifeInsurance/>}/>
          <Route path='/universal-life' element={<UniversalLifeInsurance/>}/>
          <Route path='/userdetails-payment' element={<UserDetailsAndPayment/>}/>
          



        </Routes>
      </div>
    </Router>
  );
}

export default App;
