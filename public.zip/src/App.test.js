import React from 'react';
import './styles/HomePage.css';

const HomePage = () => {
  return (
    <div className="home-page">
      <h2>Welcome to Life Insurance Portal</h2>
      <p>Your one-stop solution for all insurance needs.</p>
    </div>
  );
};

export default HomePage;
